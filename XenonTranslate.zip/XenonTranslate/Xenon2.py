x = list('abcdefghijklmnopqrstuvwxyz ')
z = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26]

def fromxenon():
    final = ""
    w = input("Word: ")
    for letter in w.split():
        if not letter == chr(32):
            final += x[int(letter)]
    print(final)
    final = ""
def toxenon():
    word = input("W: ")
    ret = ""
    for letter in word:
        ret += str(x.index(letter)) + " "
    print("Xenon Format Of Word: {}".format(ret))
while True:
    chosen = input("From or To (T or F): ")
    if chosen.lower() == "t":
        toxenon()
    else:
        fromxenon()
